# p211-21-06-2019

### Front Final Project
- Aşağıdakı linkdə olan template-dəki bütün səhifələri (navbarda link verilən bütün səhifələri) bitirməlisiniz.
  - https://colorlib.com/preview/theme/winkel/index.html

#### Deadline: 27 June 2019 14:00.
